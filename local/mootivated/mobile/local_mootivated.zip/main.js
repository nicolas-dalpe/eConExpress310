// (C) Copyright 2018 Mootivation Technologies Corp.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

/**
 * @author Frédéric Massart <fred@branchup.tech>
 */

angular.module('mm.addons.mootivated', ['ja.qr'])

// Plugin constants.
.constant('mmaMootivatedVersion', '1.0.0')
.constant('mmaMootivatedPath', 'addons/mootivated')
.constant('mmaMootivatedSideMenuNavPriority', 1)
.constant('mmaMootivatedNavIcon', 'ion-star')
.constant('mmaMootivatedCoinCountChangedEvent', 'mmaMootivatedCoinCountChanged')
.constant('mmaMootivatedPurchasesChangedEvent', 'mmaMootivatedPurchasesChanged')
.constant('mmaMootivatedSiteStore', 'mma_mootivated_site')

.config(function($stateProvider, $mmCoursesDelegateProvider, $mmSideMenuDelegateProvider,
        mmaMootivatedSideMenuNavPriority, $mmSitesFactoryProvider, mmaMootivatedSiteStore) {

    // Register the stores.
    var stores = [
        {
            name: mmaMootivatedSiteStore,
            keyPath: 'key',
        }
    ];
    $mmSitesFactoryProvider.registerStores(stores);

    // Register states.
    $stateProvider

    .state('site.mootivated', {
        url: '/mootivated',
        views: {
            'site': {
                templateUrl: 'addons/mootivated/templates/index.html',
                controller: 'mmaMootivatedIndexCtrl'
            }
        }
    });

    // Register side menu navigation handler.
    $mmSideMenuDelegateProvider.registerNavHandler('mmaMootivated', '$mmaMootivatedHandlers.sideMenuNav',
        mmaMootivatedSideMenuNavPriority);

})

.run(function($mmSite) {

    // Force remote add-on to register the store.
    if ($mmSite.isLoggedIn() && $mmSite.reloadDb) {
        $mmSite.reloadDb();
    }

});
