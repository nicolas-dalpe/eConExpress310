// (C) Copyright 2018 Mootivation Technologies Corp.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

/**
 * @author Frédéric Massart <fred@branchup.tech>
 */

angular.module('mm.addons.mootivated')

.controller('mmaMootivatedPurchasesCtrl', function($log, $scope, $stateParams, $mmaMootivated, $mmaMootivatedServerFactory,
        $mmSite, mmaMootivatedPurchasesChangedEvent) {
    $log = $log.getInstance('mmaMootivatedPurchasesCtrl');
    var server;

    $scope.loaded = false;

    function updateView() {
        return server.getPurchasedStoreItems().then(function(items) {
            $scope.items = items.map(function(item) {
                return angular.extend({}, item, {
                    is_raffle: item.type == 'Raffle',
                    is_purchase: item.type == 'Purchase',
                });
            });
        });
    }

    $scope.redeemItem = function(item) {
        server.getRedeemQRContentForItem(item).then(function(qrtext) {
            $mmaMootivated.showRedeemCode(qrtext, item, $scope).then(function() {
                updateView();
            });
        });
    };

    $scope.refresh = function() {
        updateView().finally(function() {
            $scope.$broadcast('scroll.refreshComplete');
        });
    };

    $mmaMootivatedServerFactory.getInstance($mmSite.getId()).then(function(server_) {
        server = server_;
        return updateView();
    }).catch(function() {
        $scope.error = true;
    }).finally(function() {
        $scope.loaded = true;
    });

    // Refresh the view when the purchases have changed.
    var purchaseChangeListener = $scope.$on(mmaMootivatedPurchasesChangedEvent, function(e) {
        updateView();
    });
    $scope.$on('$destroy', function() {
        purchaseChangeListener();
    });
});
