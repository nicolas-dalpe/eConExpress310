// (C) Copyright 2018 Mootivation Technologies Corp.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

/**
 * @author Frédéric Massart <fred@branchup.tech>
 */

angular.module('mm.addons.mootivated')

.controller('mmaMootivatedStoreCtrl', function($q, $log, $scope, $stateParams, $mmaMootivated, $mmaMootivatedServerFactory,
        $translate, $mmSite, $mmUtil, mmaMootivatedCoinCountChangedEvent, $mmaMootivatedUtils) {
    $log = $log.getInstance('mmaMootivatedStoreCtrl');

    var server;
    $scope.loaded = false;

    function updateView() {
        return server.getStoreItems().then(function(items) {
            var now = new Date();
            $scope.storeItems = items.map(function(item) {
                var timeLeft = Math.max(1, item.end_time - (now.getTime() / 1000));
                return angular.extend({}, item, {
                    time_left: $mmaMootivatedUtils.formatTimeLeft(timeLeft),
                    is_raffle: item.type == 'Raffle',
                    is_purchase: item.type == 'Purchase',
                    raffle_my_chances: item.raffle_total_entries > 0 ? Math.round(item.raffle_my_entries / item.raffle_total_entries * 100) : 0
                });
            });
        }).then(function() {
            return server.getCoins().then(function(coins) {
                $scope.coins = coins;
            });
        });
    }

    $scope.canBuy = function(item) {
        return $scope.coins && $scope.coins >= item.cost;
    };

    $scope.purchaseItem = function(item) {
        $mmUtil.showConfirm($translate.instant('mma.mootivated.reallypurchase', {
            item: item.name,
            cost: item.cost
        })).then(function() {
            var modal = $mmUtil.showModalLoading('mma.mootivated.purchasing', true);
            server.purchaseStoreItem(item).then(function() {
                return updateView().then(function() {
                    $scope.notifyPurchasesChange();
                    $scope.notifyCoinCountChange($scope.coins);
                });
            }).then(function() {
                $mmUtil.showModal('mm.core.success', 'mma.mootivated.itempurchasedsuccessfully');
            }).catch(function() {
                $mmUtil.showErrorModal('mma.mootivated.erroruponpurchase', true);
            }).finally(function() {
                modal.dismiss();
            });
        });
    };

    $scope.refresh = function() {
        updateView().finally(function() {
            $scope.$broadcast('scroll.refreshComplete');
        });
    };

    $mmaMootivatedServerFactory.getInstance($mmSite.getId()).then(function(server_) {
        server = server_;
        return updateView();
    }).catch(function() {
        $scope.error = true;
    }).finally(function() {
        $scope.loaded = true;
    });

    var coinChangeListener = $scope.$on(mmaMootivatedCoinCountChangedEvent, function(e, args) {
        $scope.coins = args.coinCount;
    });
    $scope.$on('$destroy', function() {
        coinChangeListener();
    });
});
