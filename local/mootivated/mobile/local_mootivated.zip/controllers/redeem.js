// (C) Copyright 2018 Mootivation Technologies Corp.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

/**
 * @author Frédéric Massart <fred@branchup.tech>
 */

angular.module('mm.addons.mootivated')

.controller('mmaMootivatedRedeemCtrl', function($q, $log, $scope, $stateParams, $mmaMootivated, $mmaMootivatedServerFactory,
        $mmSite, $mmUtil) {

    $log = $log.getInstance('mmaMootivatedRedeemCtrl');
    var server,
        scanner;

    function closeScanner() {
        scanner && scanner.hide();
        $scope.scannerOn = false;
        scanner = null;
    }

    $scope.launchScanner = function() {
        var loading;
        $scope.scannerOn = true;
        scanner = $mmaMootivated.scanQRCode();
        scanner.promise.then(function(text) {
            var info = $mmaMootivated.getRedeemInfoFromCode(text);
            if (!info) {
                return $q.reject({ name: 'INVALID_QR' });
            }

            // We got the code, let's show a loading dialogue.
            closeScanner();
            loading = $mmUtil.showModalLoading();

            return server.redeemStoreItem(info.userId, info.itemId).then(function() {
                loading && loading.dismiss();
                $mmUtil.showModal('mm.core.success', 'mma.mootivated.successfullyredeemeditem');

            }).catch(function() {
                return $q.reject({ name: 'ERROR_REDEEMING' });
            });
        }).catch(function(err) {

            // Repeat the close in case the reject happened before we got a code.
            closeScanner();
            loading && loading.dismiss();

            if (err) {
                if (err.name === 'ERROR_REDEEMING') {
                    $mmUtil.showErrorModal('mma.mootivated.errorwhileredeeming', true);
                } else {
                    $mmUtil.showErrorModal('mma.mootivated.errorwhilescanning', true);
                }
            }
        }).finally(function() {
        });
    };

    $scope.closeScanner = closeScanner;

    $mmaMootivatedServerFactory.getInstance($mmSite.getId()).then(function(server_) {
        server = server_;
    }).catch(function() {
        $scope.error = true;
    }).finally(function() {
        $scope.loaded = true;
    });
});
