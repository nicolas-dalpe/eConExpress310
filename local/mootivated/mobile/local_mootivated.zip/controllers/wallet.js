// (C) Copyright 2018 Mootivation Technologies Corp.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

/**
 * @author Frédéric Massart <fred@branchup.tech>
 */

angular.module('mm.addons.mootivated')

.controller('mmaMootivatedWalletCtrl', function($q, $log, $scope, $stateParams, $mmaMootivated, $mmaMootivatedServerFactory,
        $mmSite, mmaMootivatedCoinCountChangedEvent) {

    $log = $log.getInstance('mmaMootivatedWalletCtrl');

    var server,
        firstLoad = true;

    $scope.loaded = false;
    $scope.lastCoins = null;

    function updateView() {
        var promise = $q.when();

        if (!firstLoad) {
            // On the first load, we should not need to invalidate the coin count.
            server.invalidateCoinCount();
        }

        return promise.then(function() {
            var promise = $q.when(),
                lastCoins = 0;

            if (firstLoad) {
                firstLoad = false;
                promise = server.getLastKnownCoins().then(function(lastCoins_) {
                    if (lastCoins_ !== null) {
                        lastCoins = lastCoins_;
                    }
                }).catch(function() {
                    // Do not reject this promise, ever.
                });
            }

            return promise.then(function() {
                return server.getCoins().then(function(coins) {
                    $scope.coins = coins;
                    $scope.notifyCoinCountChange(coins);

                    $scope.showGainsSinceLast = lastCoins > 0 && coins > lastCoins;
                    if ($scope.showGainsSinceLast) {
                        $scope.coinsGained = coins - lastCoins;
                    }
                });
            });
        });
    }

    $scope.refresh = function() {
        updateView().finally(function() {
            $scope.$broadcast('scroll.refreshComplete');
        });
    };

    $mmaMootivatedServerFactory.getInstance($mmSite.getId()).then(function(server_) {
        server = server_;
        return updateView();
    }).catch(function() {
        $scope.error = true;
    }).finally(function() {
        $scope.loaded = true;
    });

    var coinChangeListener = $scope.$on(mmaMootivatedCoinCountChangedEvent, function(e, args) {
        $scope.coins = args.coinCount;
    });
    $scope.$on('$destroy', function() {
        coinChangeListener();
    });
});
