// (C) Copyright 2018 Mootivation Technologies Corp.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

/**
 * @author Frédéric Massart <fred@branchup.tech>
 */

angular.module('mm.addons.mootivated')

.controller('mmaMootivatedIndexCtrl', function($log, $scope, $stateParams, $mmaMootivated, $mmaMootivatedServerFactory,
        $mmSite, mmaMootivatedPath, mmaMootivatedCoinCountChangedEvent, mmaMootivatedPurchasesChangedEvent) {

    $log = $log.getInstance('mmaMootivatedIndexCtrl');

    // We must declare the path in Javascript so that remote addons can replace it.
    $scope.addonPath = mmaMootivatedPath;
    $scope.title = $mmaMootivated.getTitle();
    $scope.error = false;
    $scope.loaded = false;
    $scope.canRedeem = false;

    // Set a function which is shared amongst children (the tabs) so that they can use it to notify
    // other tabs when the number of coins is expected to be changed.
    $scope.notifyCoinCountChange = function(coinCount) {
        $scope.$broadcast(mmaMootivatedCoinCountChangedEvent, { coinCount: coinCount });
    };

    // Set a function which is shared amongst children (the tabs) so that they can use it to notify
    // other tabs when the purchases have changed, typically when the user has purchased something.
    $scope.notifyPurchasesChange = function() {
        $scope.$broadcast(mmaMootivatedPurchasesChangedEvent);
    };

    $mmaMootivatedServerFactory.getInstance($mmSite.getId()).then(function(server) {
        return server.preload().then(function() {
            return server.canRedeemStoreItems().then(function(canRedeemStoreItems) {
                $scope.canRedeem = $mmaMootivated.isQRCodeScannerAvailable() && canRedeemStoreItems;
            });
        });
    }).catch(function() {
        $scope.error = true;
    }).finally(function() {
        $scope.loaded = true;
    });
});
