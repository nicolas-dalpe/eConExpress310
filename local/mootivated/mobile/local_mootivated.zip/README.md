Motrain for Moodle Mobile
=========================

Mootivated/Motrain addon for Moodle Mobile.

Requirements
------------

- Moodle >= 3.2
- Moodle plugin: local_mootivated

### For redeeming items

Redeeming items requires a QR code reader, and thus an additional Cordova plugin. You will need to build your own version of the Moodle Mobile app to enable support for this feature. Though note that you do not need to include
the add-on in your build, the remote add-on will automatically detect when the QR code scanner is installed.

    $ ionic plugin add cordova-plugin-qrscanner

License
-------

[Apache 2.0](http://www.apache.org/licenses/LICENSE-2.0)
