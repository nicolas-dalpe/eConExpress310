// (C) Copyright 2018 Mootivation Technologies Corp.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

/**
 * @author Frédéric Massart <fred@branchup.tech>
 */

angular.module('mm.addons.mootivated')

.factory('$mmaMootivated', function($q, $log, $translate, $mmLang, $mmSite, $ionicPopup, $ionicPlatform) {
    $log = $log.getInstance('$mmaMootivated');

    var self = {},
        optimisticSetupCache = {};

    /**
     * Cache key for setup.
     *
     * @return {string}
     */
    function getCacheKeyForSetup() {
        return 'mmaMootivated:setup';
    }

    /**
     * Get the setup optimistic cache.
     *
     * @return {Object}
     */
    function getOptimisticSetupCache() {
        if (optimisticSetupCache && optimisticSetupCache.__siteId == $mmSite.getId()) {
            return optimisticSetupCache;
        }
        return;
    }

    /**
     * Get redeem info from code.
     *
     * @param {String} text The code.
     * @return {False|Object}
     */
    self.getRedeemInfoFromCode = function(text) {
        if (!text) {
            return false;
        }
        var parts = text.split(',');
        if (parts.length != 4) {
            return false;
        }
        if (parts[0] !== 'Mootivated' || parts[1] !== 'Redeem') {
            return false;
        }

        return {
            userId: parts[2],
            itemId: parts[3],
        };
    };

    /**
     * Get setup information.
     *
     * @return {Promise} Resolved with response data.
     */
    self.getSetup = function() {
        var presets = {
            cacheKey: getCacheKeyForSetup()
        };
        return $mmSite.read('local_mootivated_get_setup', {}, presets).then(function(response) {
            optimisticSetupCache = response;
            optimisticSetupCache.__siteId = $mmSite.getId();
            return response;
        });
    };

    /**
     * Get title.
     *
     * @return {String}
     */
    self.getTitle = function() {
        var cache = getOptimisticSetupCache();
        if (cache && cache.title) {
            return cache.title;
        }
        return $translate.instant('mma.mootivated.sidebartitle');
    };

    /**
     * Is the plugin enabled?
     *
     * The plugin requires Moodle 3.2 to be installed due to some API limitations.
     *
     * @return {Boolean}
     */
    self.isPluginEnabled = function() {
        return $mmSite.isLoggedIn()
            && $mmSite.wsAvailable('local_mootivated_get_setup', false)
            && $mmSite.isVersionGreaterEqualThan('3.2.0');
    };

    /**
     * Is the QR code scanner available?
     *
     * @return {Boolean}
     */
    self.isQRCodeScannerAvailable = function() {
        return typeof window.QRScanner !== 'undefined';
    };

    /**
     * Is visible?
     *
     * @return {Promise}
     */
    self.isVisible = function() {
        return self.getSetup().then(function(setup) {
            // The Moodle site should confirm whether they should see the link, and thus be
            // able to login and establish communication between MM and Moodle.
            return setup.is_visible;
        }).catch(function() {
            return false;
        });
    };

    /**
     * Scan a QR code.
     *
     * @return {Object}
     */
    self.scanQRCode = function() {
        if (!QRScanner) {
            return $q.reject({
                name: 'NO_SCANNER'
            });
        }

        var deferred = $q.defer(),
            body = angular.element(document).find('body')[0],
            before = function() { body.classList.add('mma-mootivated-qr-scanner'); },
            after = function() { body.classList.remove('mma-mootivated-qr-scanner'); };

        QRScanner.scan(function(err, text) {
            if (err) {
                $log.debug('QR Scanner errored: ' + err.name);
                if (err.name !== 'SCAN_CANCELED') {
                    deferred.reject(err);
                    return;
                }
                deferred.reject();
                return;
            }
            $log.debug('QR Scanner read: ' + text);
            deferred.resolve(text);
        });

        QRScanner.show();
        before();

        var backButtonDeregister = $ionicPlatform.registerBackButtonAction(function() {
            // Treat this as a cancel, and let the calling code dismiss the reader.
            deferred.reject();
        }, 500);

        return {
            hide: function() {
                backButtonDeregister();
                QRScanner.destroy();
                after();
            },
            promise: deferred.promise
        };
    };

    /**
     * Show the redeem code.
     *
     * @param {String} qrtext The QR code content.
     * @param {Object} item The item.
     * @param {Object} scope The parent scope.
     * @return {Promise}
     */
    self.showRedeemCode = function(qrtext, item, scope) {
        var newScope = scope.$new();
        newScope.code = qrtext;
        newScope.item = item;
        return $ionicPopup.alert({
            title: $translate.instant('mma.mootivated.redeemitem'),
            template: '<div style="text-align: center;">'
                + '<p>{{ "mma.mootivated.showcodetoredeem" | translate:{item:item.name} }}</p>'
                + '<qr text="code" size="200"></qr>'
                + '</div>',
            scope: newScope
        });
    };

    return self;
});
