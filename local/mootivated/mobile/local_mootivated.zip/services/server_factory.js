// (C) Copyright 2018 Mootivation Technologies Corp.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

/**
 * @author Frédéric Massart <fred@branchup.tech>
 */

angular.module('mm.addons.mootivated')

.factory('$mmaMootivatedServerFactory', function($q, $log, $http, $mmLang, $mmSitesManager, mmaMootivatedSiteStore) {
    $log = $log.getInstance('$mmaMootivatedServerFactory');

    var instances = {};

    function MootivatedServerFactory(siteId) {
        // Private variables.
        var mmSite,
            loginInfo,
            coinCount = 0;

        function doLogin() {
            $log.debug('About to log the user in');
            return $mmLang.getCurrentLanguage().then(function(lang) {
                return mmSite.read('local_mootivated_login', {
                    'language_code': lang
                }, {
                    getFromCache: false,
                    saveToCache: false
                }).then(function(data) {
                    var result;
                    try {
                        result = JSON.parse(data.result);
                    } catch(e) {
                    }

                    if (!result || !result.api_key) {
                        $log.debug('Login operation did not succeed');
                        return $q.reject();
                    }

                    $log.debug('Login operation succeeded');
                    var entry = {
                        school_id: result.school_id,
                        user_id: result.user_id,    // The user_id on Motrain's server.
                        can_redeem_store_items: data.can_redeem_store_items,
                        coins: result.coins || 0,

                        host: data.server_ip,
                        api_key: result.api_key,
                        app_eula_url: result.app_eula_url,
                        file_storage_key: result.file_storage_key,
                        file_storage_url: result.file_storage_url
                    };

                    return entry;
                });
            });
        }

        function ensureEverythingIsReady() {
            var now = new Date();
            if (loginInfo && loginInfo._expires > now.getTime()) {
                return $q.when();
            }
            return updateLoginInfo();
        }

        function executeWhenReady(fn) {
            return function() {
                var args = arguments;
                return ensureEverythingIsReady().then(function() {
                    return fn.apply(null, args);
                });
            };
        }

        function getApiKey() {
            return loginInfo.api_key;
        }

        function getHost() {
            return loginInfo.host;
        }

        function getToken() {
            return '1amt0ken';
        }

        function getSchoolId() {
            return loginInfo.school_id;
        }

        function getStorageRoot() {
            return loginInfo.file_storage_url;
        }

        function getUserId() {
            return loginInfo.user_id;
        }

        function httpPost(endpoint, data) {
            return $http({
                url: 'https://' + getHost() + endpoint,
                method: 'POST',
                data: JSON.stringify(data),
                headers: {
                    'Content-Type': 'application/json',
                    'X-Moot-Auth': getApiKey()
                }
            }).then(function(response) {
                if (response.status < 200 || response.status >= 300) {
                    return $q.reject();
                }
                return response.data;
            });
        }

        function postProcessStoreItems(items) {
            var url = getStorageRoot(),
                userId = getUserId();

            return items.map(function(item) {
                var myentries = 0;
                var allentries = 0;
                angular.forEach(item.raffle_entries, function(entry) {
                    if (entry.user_id == userId) {
                        myentries += entry.num_entries;
                    }
                    allentries += entry.num_entries;
                });

                return angular.extend({}, item, {
                    image_url: url + item.image_url,

                    // Add own keys here, hopefully they will never be overriding received values.
                    raffle_my_entries: myentries,
                    raffle_total_entries: allentries,
                });
            });
        }

        function updateCoinCount() {
            return updateLoginInfo();
        }

        function updateLastKnownCoinCount(coins) {
            // The mmDb.update function does not seem to be used, so we remove and insert.
            return mmSite.getDb().remove(mmaMootivatedSiteStore, 'lastknowncoincount').then(function() {
                return mmSite.getDb().insert(mmaMootivatedSiteStore, {
                    key: 'lastknowncoincount',
                    coincount: coins
                });
            });
        }

        function updateLoginInfo() {
            var now = new Date();
            return doLogin().then(function(info) {
                // Keep the loginInfo in static cache for up to a day.
                loginInfo = angular.extend({_expires: now.getTime() + (86400 * 1000)}, info);
                coinCount = info.coins;
            });
        }

        /** Public API. */

        function canRedeemStoreItems() {
            return $q.when(loginInfo.can_redeem_store_items);
        }

        function getCoins() {
            var promise = $q.when(coinCount);

            if (coinCount === null) {
                promise = updateCoinCount().then(function() {
                    return coinCount;
                });
            }

            return promise.then(function(coins) {
                // This API is the way to fetching the current coin count, therefore, that is here that we
                // save the last known coin count. To get the last coin count, you must call the method
                // getLastKnownCoins prior to calling getCoins.
                updateLastKnownCoinCount(coins);
                return coins;
            });
        }

        function getLastKnownCoins() {
            return mmSite.getDb().get(mmaMootivatedSiteStore, 'lastknowncoincount').then(function(entry) {
                return entry.coincount;
            }).catch(function() {
                return null;
            }).then(function(coins) {
                $log.debug('Last known coin count is: ' + coins);
                return coins;
            });
        }

        function getPurchasedStoreItems() {
            return httpPost('/store/get_purchased_items', {
                'user_id': getUserId(),
                'token': getToken()
            }).then(function(data) {
                var quantities = data.purchased_item_ids.reduce(function(carry, itemId) {
                    if (typeof carry[itemId] === 'undefined') {
                        carry[itemId] = 0;
                    }
                    carry[itemId] += 1;
                    return carry;
                }, {});
                return postProcessStoreItems(data.item_definitions).map(function(item) {
                    return angular.extend({}, item, {
                        // Add own key.
                        my_quantity: typeof quantities[item.id] === 'undefined' ? 0 : quantities[item.id]
                    });
                });
            });
        }

        function getRedeemQRContentForItem(item) {
            return $q.when('Mootivated,Redeem,' + getUserId() + ',' + item.id);
        }

        function getStoreItems() {
            var userId = getUserId();
            $log.debug('Retrieving store items');
            return httpPost('/store/get', {
                'user_id': userId,
                'school_id': getSchoolId(),
                'token': getToken()
            }).then(function(data) {
                // Post-process the results.
                return postProcessStoreItems(data.store_items);
            });
        }

        function invalidateCoinCount() {
            coinCount = null;
            return $q.when();
        }

        function purchaseStoreItem(item) {
            return httpPost('/store/purchase_item', {
                user_id: getUserId(),
                token: getToken(),
                store_item_id: item.id,
            }).then(function() {
                coinCount = Math.max(0, coinCount - item.cost);
            });
        }

        function redeemStoreItem(forUserId, itemId) {
            return httpPost('/store/redeem_item', {
                user_id: getUserId(),
                token: getToken(),
                user_id_to_redeem: forUserId,
                purchased_item_id: itemId
            });
        }

        return $mmSitesManager.getSite(siteId).then(function(site) {
            mmSite = site;
            return {
                canRedeemStoreItems: executeWhenReady(canRedeemStoreItems),
                getCoins: executeWhenReady(getCoins),
                getLastKnownCoins: executeWhenReady(getLastKnownCoins),
                getPurchasedStoreItems: executeWhenReady(getPurchasedStoreItems),
                getRedeemQRContentForItem: executeWhenReady(getRedeemQRContentForItem),
                getStoreItems: executeWhenReady(getStoreItems),
                invalidateCoinCount: invalidateCoinCount,
                purchaseStoreItem: executeWhenReady(purchaseStoreItem),
                preload: executeWhenReady(function() {}),
                redeemStoreItem: executeWhenReady(redeemStoreItem),
            };
        });
    }

    return {
        getInstance: function(siteId) {
            if (!instances || !instances[siteId]) {
                instances[siteId] = MootivatedServerFactory(siteId);
            }
            return $q.when(instances[siteId]);
        }
    };
});
